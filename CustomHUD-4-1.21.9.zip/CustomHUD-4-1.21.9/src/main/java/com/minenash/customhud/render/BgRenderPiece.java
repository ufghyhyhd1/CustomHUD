package com.minenash.customhud.render;

public class BgRenderPiece {
    public int x;
    public int y;
    public int width;
    public int height;
    public int color;

    public BgRenderPiece(int x, int y, int width, int height, int color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
    }


}
