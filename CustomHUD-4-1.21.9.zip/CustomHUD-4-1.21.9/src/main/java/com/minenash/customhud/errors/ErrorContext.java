package com.minenash.customhud.errors;

public record ErrorContext(String profileName, int line, String src) {}
