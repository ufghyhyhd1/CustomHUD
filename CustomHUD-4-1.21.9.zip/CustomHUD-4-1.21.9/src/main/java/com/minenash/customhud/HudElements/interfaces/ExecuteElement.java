package com.minenash.customhud.HudElements.interfaces;

public interface ExecuteElement {

    void run();

}
