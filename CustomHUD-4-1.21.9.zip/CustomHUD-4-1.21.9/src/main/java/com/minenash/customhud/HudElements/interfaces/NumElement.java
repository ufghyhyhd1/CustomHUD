package com.minenash.customhud.HudElements.interfaces;

public interface NumElement {

    int getPrecision();

}
