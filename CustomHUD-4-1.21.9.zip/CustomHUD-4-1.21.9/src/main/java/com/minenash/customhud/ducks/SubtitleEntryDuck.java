package com.minenash.customhud.ducks;

import net.minecraft.util.Identifier;

public interface SubtitleEntryDuck {

    Identifier customhud$getSoundID();
    void customhud$setSoundID(Identifier id);

}
