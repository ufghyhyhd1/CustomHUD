# CustomHUD
A highly customizable variable-based text HUD for Minecraft 

Under the MIT License 
